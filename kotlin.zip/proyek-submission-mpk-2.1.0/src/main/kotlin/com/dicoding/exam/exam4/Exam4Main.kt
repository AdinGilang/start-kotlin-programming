package com.dicoding.exam.exam4

private fun main() {
    println(
        """
        My Map Result:
        ${vehicle()}
        """.trimIndent()
    )
}
