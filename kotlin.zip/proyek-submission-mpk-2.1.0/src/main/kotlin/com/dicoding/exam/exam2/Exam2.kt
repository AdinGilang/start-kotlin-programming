package com.dicoding.exam.exam2

// TODO 1
fun calculate(valueA: Int, valueB: Int, valueC: Int?): Int {
    val ValueC = valueC ?:50
    val result = valueA + (valueB - ValueC)
    return result
}

// TODO 2
fun result(result: Int): String {
    return "Result is $result"
}