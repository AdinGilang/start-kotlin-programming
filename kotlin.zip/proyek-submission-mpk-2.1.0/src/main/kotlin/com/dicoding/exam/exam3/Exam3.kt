package com.dicoding.exam.exam3

// TODO
fun <T> checkType(args: T): String {
    val dataType = when (args){
        is Int -> "Integer"
        is Boolean -> "Boolean"
        is String -> "String"
        is Double -> "Double"
        is List<*> -> "List"
        is Map<*, *> -> "Map"
        else -> "Unknown"
    }
    return "Yes! it's $dataType"
}